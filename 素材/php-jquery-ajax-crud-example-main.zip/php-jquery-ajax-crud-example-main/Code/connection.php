<?php

$server_name= "localhost";
$user_name= "root";
$password= "usbw";
$database_name= "phpajax";
$conn= mysqli_connect($server_name , $user_name , $password , $database_name); 
if ($conn) { 
//echo "connected" ; 
}

?> 

