{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "id": "001"
    ,"username": "用户-1"
    ,"avatar": "https://wx4.sinaimg.cn/mw1024/5db11ff4gy1fmx4keaw9pj20dw08caa4.jpg"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "男"
    ,"ip": "1111111"
    ,"jointime": 20171204
  },{
    "id": "002"
    ,"username": "用户-2"
    ,"avatar": "https://wx4.sinaimg.cn/mw1024/5db11ff4gy1fmx4keaw9pj20dw08caa4.jpg"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "男"
    ,"ip": "1111111"
    ,"jointime": 20171204
  },{
    "id": "003"
    ,"username": "用户-3"
    ,"avatar": "https://wx2.sinaimg.cn/mw690/5db11ff4gy1fmx4kec5bvj20eb0h3mxh.jpg"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "女"
    ,"ip": "1111111"
    ,"jointime": 20171011
    ,"LAY_CHECKED": true
  },{
    "id": "004"
    ,"username": "用户-4"
    ,"avatar": "https://wx4.sinaimg.cn/mw1024/5db11ff4gy1fmx4keaw9pj20dw08caa4.jpg"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "男"
    ,"ip": "1111111"
    ,"jointime": 20160505
  },{
    "id": "005"
    ,"username": "用户-5"
    ,"avatar": "https://wx2.sinaimg.cn/mw690/5db11ff4gy1fmx4kec5bvj20eb0h3mxh.jpg"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "男"
    ,"ip": "1111111"
    ,"jointime": 20171204
  },{
   "id": "006"
    ,"username": "用户-6"
    ,"avatar": "https://wx2.sinaimg.cn/mw690/5db11ff4gy1fmx4kec5bvj20eb0h3mxh.jpg"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "男"
    ,"ip": "1111111"
    ,"jointime": 20171204
  },{
    "id": "007"
    ,"username": "用户-7"
    ,"avatar": "https://wx3.sinaimg.cn/mw690/5db11ff4gy1fmx4keca8ag208g06iglw.gif"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "男"
    ,"ip": "1111111"
    ,"jointime": 20180210
  },{
    "id": "008"
    ,"username": "用户-8"
    ,"avatar": "https://wx2.sinaimg.cn/mw690/5db11ff4gy1fmx4kec5bvj20eb0h3mxh.jpg"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "女"
    ,"ip": "1111111"
    ,"jointime": 20171204
  },{
   "id": "009"
    ,"username": "用户-9"
    ,"avatar": "https://wx2.sinaimg.cn/mw690/5db11ff4gy1fmx4kec5bvj20eb0h3mxh.jpg"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "女"
    ,"ip": "1111111"
    ,"jointime": 20171204
  },{
    "id": "010"
    ,"username": "用户-10"
    ,"avatar": "https://wx4.sinaimg.cn/mw1024/5db11ff4gy1fmx4keaw9pj20dw08caa4.jpg"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "男"
    ,"ip": "1111111"
    ,"jointime": 20170719
  },{
    "id": "011"
    ,"username": "用户-11"
    ,"avatar": "https://wx2.sinaimg.cn/mw690/5db11ff4gy1fmx4kec5bvj20eb0h3mxh.jpg"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "男"
    ,"ip": "1111111"
    ,"jointime": 20171204
  },{
    "id": "012"
    ,"username": "用户-12"
    ,"avatar": "https://wx2.sinaimg.cn/mw690/5db11ff4gy1fmx4kec5bvj20eb0h3mxh.jpg"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "女"
    ,"ip": "1111111"
    ,"jointime": 20171204
  },{
    "id": "013"
    ,"username": "用户-13"
    ,"avatar": "https://wx2.sinaimg.cn/mw690/5db11ff4gy1fmx4kec5bvj20eb0h3mxh.jpg"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "女"
    ,"ip": "1111111"
    ,"jointime": 20171204
    ,"LAY_CHECKED": true
  },{
    "id": "014"
    ,"username": "用户-14"
    ,"avatar": "https://wx3.sinaimg.cn/mw690/5db11ff4gy1fmx4keca8ag208g06iglw.gif"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "男"
    ,"ip": "1111111"
    ,"jointime": 20171204
  },{
    "id": "015"
    ,"username": "用户-15"
    ,"avatar": "https://wx2.sinaimg.cn/mw690/5db11ff4gy1fmx4kec5bvj20eb0h3mxh.jpg"
    ,"phone": 12345678901
    ,"email": "11111@qq.com"
    ,"sex": "男"
    ,"ip": "1111111"
    ,"jointime": 20171204
  }]
}